# Java Calculator
- ### Programming language: Java
- ### Using IDE: Netbeans
- ### Layout Tool: Scene Builder
- ### Some buttons do not correctly work.
- ### Date Created: 24jan,2020.


## Screenshot
<img width="300px" src="https://raw.githubusercontent.com/ShahriarShafin/java_calculator/master/calculator.png">
                                  
                                   
